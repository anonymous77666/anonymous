// === OFFICIAL CREDENTIALS (CONFIGURED) ===
// Atenção: armazenar credenciais no front-end NÃO é seguro. Você pediu que as credenciais fossem oficiais
// e eu as coloquei aqui por sua solicitação. Qualquer pessoa que abra o código-fonte verá essas strings.
// Para segurança verdadeira, implemente autenticação no servidor (ex: Firebase Auth, Auth0, backend próprio).
const OFFICIAL_USER = 'RickAlves76';
const OFFICIAL_PASS = 'Rick04052023';

// --- Matrix background ---
const canvas = document.getElementById('matrix');
const ctx = canvas.getContext('2d');
function fitCanvas(){canvas.width = innerWidth; canvas.height = innerHeight}
fitCanvas(); window.addEventListener('resize', fitCanvas);
const cols = Math.floor(innerWidth / 14);
const drops = Array(cols).fill(0).map(()=>Math.random()*innerHeight);
const CHARS = '01█░▒▓<>/\\\\|!@#$%^&*()_+-=[]{};:\\\\\"\\\\',.<>?';
function draw(){
  ctx.fillStyle = 'rgba(0,0,0,0.06)'; ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.font='13px monospace';
  for(let i=0;i<drops.length;i++){
    const txt = CHARS.charAt(Math.floor(Math.random()*CHARS.length));
    const x = i*14; const y = drops[i]*14;
    ctx.fillStyle = '#00ff6a'; ctx.fillText(txt,x,y);
    drops[i] = drops[i] > canvas.height/14 + Math.random()*100 ? 0 : drops[i]+0.75;
  }
  requestAnimationFrame(draw);
}
draw();

// --- Login flow ---
const loginForm = document.getElementById('loginForm');
const loginView = document.getElementById('loginView');
const dashboardView = document.getElementById('dashboardView');
const opName = document.getElementById('opName');
const logs = document.getElementById('logs');
const lastUpdate = document.getElementById('lastUpdate');

function log(msg){const el=document.createElement('div');el.textContent=`[${new Date().toLocaleTimeString()}] ${msg}`;logs.prepend(el)}

loginForm.addEventListener('submit', async (ev)=>{
  ev.preventDefault();
  const user = document.getElementById('user').value.trim();
  const pass = document.getElementById('pass').value.trim();
  log('tentativa de login — ' + user);
  // official auth check (client-side)
  if(user===OFFICIAL_USER && pass===OFFICIAL_PASS){
    log('autenticação OK (oficial)');
    // play entry animation
    loginView.style.transition='opacity 700ms'; loginView.style.opacity='0';
    setTimeout(()=>{loginView.style.display='none'; dashboardView.style.display='block'; dashboardView.style.opacity='0'; dashboardView.style.transition='opacity 800ms'; setTimeout(()=>dashboardView.style.opacity='1',20)},750);
    opName.textContent = user;
    setTimeout(()=>{loadStatesDemo()},900);
  } else {
    log('falha na autenticação'); alert('Credenciais incorretas');
  }
});

// --- Map interactions ---
const stateGroups = document.querySelectorAll('.stateG');
const tooltip = document.getElementById('tooltip');
const pulsesGroup = document.getElementById('pulses');

// demo data
function generateDemoStates(){
  const codes = ['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'];
  return codes.map(c=>({code:c,value:Math.floor(Math.random()*600)}));
}

function clearPulses(){pulsesGroup.innerHTML=''}
function addPulse(x,y,size,delay){
  const ns = document.createElementNS('http://www.w3.org/2000/svg','circle');
  ns.setAttribute('cx',x); ns.setAttribute('cy',y); ns.setAttribute('r',6); ns.setAttribute('class','pulse');
  pulsesGroup.appendChild(ns);
  ns.animate([
    {r:6, opacity:0.9, offset:0}, {r: size, opacity:0.18, offset:0.6}, {r:6, opacity:0.9, offset:1}
  ],{duration:1800+Math.random()*1400,iterations:Infinity,delay:delay});
}

function loadStatesDemo(){
  log('carregando dados dos estados (demo)');
  const data = generateDemoStates();
  lastUpdate.textContent = new Date().toLocaleTimeString();
  clearPulses();
  // mapping approximate positions (match transforms in SVG)
  const POS = {
    'AC':[130,260],'AM':[275,100],'PA':[420,120],'AP':[560,70],'RR':[170,40],'RO':[120,170],
    'PI':[560,180],'CE':[630,170],'RN':[730,170],'PB':[740,210],'PE':[680,220],'AL':[720,245],'SE':[760,260],'BA':[660,280],
    'MT':[420,300],'GO':[360,360],'DF':[430,370],'MG':[510,420],'SP':[650,420],'RJ':[610,360],'PR':[730,480],'SC':[750,520],'RS':[790,555]
  };
  data.forEach((s,idx)=>{
    const pos = POS[s.code];
    if(pos){ addPulse(pos[0], pos[1], 18 + (s.value/30), idx*60); }
    // add label of value on console
  });

  // attach hover/click behavior per state
  stateGroups.forEach(g=>{
    g.onmouseenter = (ev)=>{
      const id = g.id.replace('BR-','');
      const d = data.find(x=>x.code===id) || {value:'—'};
      tooltip.style.display='block'; tooltip.innerText = id + ' • atividade: ' + d.value;
    }
    g.onmousemove = (ev)=>{tooltip.style.left = (ev.pageX+12)+'px'; tooltip.style.top=(ev.pageY+10)+'px'}
    g.onmouseleave = ()=>{tooltip.style.display='none'}
    g.onclick = ()=>{ const id = g.id.replace('BR-',''); alert('Você clicou em '+id+' — demo. \\nAbrir painel externo?'); }
  });

  log('dados dos estados carregados (demo)');
}

// Actions
document.getElementById('btnPuxar').addEventListener('click', ()=>{
  window.open('https://www.vexpainel.com/','_blank'); log('abrindo vexpainel.com');
});
document.getElementById('btnRadar').addEventListener('click', ()=>{ alert('Radar — função demo'); log('radar executado (demo)'); });
document.getElementById('btnInv').addEventListener('click', ()=>{ alert('Investigações — função demo'); log('iniciando investigação (demo)'); });
